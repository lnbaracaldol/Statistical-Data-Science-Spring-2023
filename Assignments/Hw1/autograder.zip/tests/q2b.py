OK_FORMAT = True
test = {   'name': 'q2b',
    'points': 3,
    'suites': [   {   'cases': [{'code': '>>> \n>>> assert isinstance(rising_candidate, str) and isinstance(falling_candidate, str) \n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
