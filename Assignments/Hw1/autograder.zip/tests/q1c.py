OK_FORMAT = True
test = {   'name': 'q1c',
    'points': 3,
    'suites': [   {   'cases': [   {'code': ">>> \n>>> len(election_sub['bin'].unique())\n19", 'hidden': False, 'locked': False},
                                   {   'code': '>>> \n'
                                               ">>> election_sub['bin'].value_counts()\n"
                                               '(-0.001, 0.0526]    843\n'
                                               '(0.947, 1.0]        655\n'
                                               '(0.105, 0.158]       42\n'
                                               '(0.842, 0.895]       42\n'
                                               '(0.895, 0.947]       32\n'
                                               '(0.0526, 0.105]      32\n'
                                               '(0.211, 0.263]       30\n'
                                               '(0.737, 0.789]       30\n'
                                               '(0.158, 0.211]       28\n'
                                               '(0.789, 0.842]       28\n'
                                               '(0.368, 0.421]       22\n'
                                               '(0.579, 0.632]       22\n'
                                               '(0.263, 0.316]       17\n'
                                               '(0.316, 0.368]       17\n'
                                               '(0.632, 0.684]       17\n'
                                               '(0.684, 0.737]       17\n'
                                               '(0.474, 0.526]       16\n'
                                               '(0.421, 0.474]       15\n'
                                               '(0.526, 0.579]       15\n'
                                               'Name: bin, dtype: int64',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
